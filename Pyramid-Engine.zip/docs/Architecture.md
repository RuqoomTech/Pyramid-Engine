# Architecture

## Scope

Pyramid Engine is a monolithic C++17 library with a Win32/WGL platform implementation and an OpenGL backend. CMake exports the installed library as `Pyramid::Engine`.

## Layers

| Layer | Namespace | Responsibility |
|---|---|---|
| Core | `Pyramid` | Application lifecycle, common types, and graphics API selection |
| Platform | `Pyramid` | Window, message pump, and OpenGL context |
| Graphics resources | `Pyramid` | Device, buffers, arrays, shaders, textures, framebuffers, and camera |
| Renderer | `Pyramid::Renderer` | Command recording, materials, render targets, and render passes |
| Scene | `Pyramid` | Scene graph, render objects, lights, and environment |
| Spatial management | `Pyramid::SceneManagement` | Scene manager, octree, AABB, and query helpers |
| Math | `Pyramid::Math` | Vectors, matrices, quaternions, geometry, and SIMD helpers |
| Utilities | `Pyramid::Util` | Logging, image loading, bit reading, DEFLATE, and zlib |

Input, audio, physics, editor, scripting, and asset-pipeline systems are not currently present.

## Application lifecycle

1. `Game` creates `Win32OpenGLWindow` for `GraphicsAPI::OpenGL`.
2. The window creates a temporary WGL context to load extensions.
3. It attempts core contexts from OpenGL 4.6 down to 3.3.
4. Context creation fails if no OpenGL 3.3-or-newer core context is available.
5. `IGraphicsDevice::Create` creates `OpenGLDevice`.
6. `Game::run()` calls `onCreate()`, processes messages, computes clamped delta time, updates, renders, and shuts down.

Derived `onCreate()` implementations must call `Game::onCreate()` before creating graphics resources.

## Window contract

`Window` is a strict interface. Initialization, presentation, context activation, close state, title, size, position, visibility, and minimized/maximized queries are all required operations. `Win32OpenGLWindow` implements the complete contract and updates its dimensions on `WM_SIZE`.

## Graphics device

`IGraphicsDevice` is the backend-neutral resource and draw interface. Only its OpenGL implementation exists. DirectX and Vulkan enum values are reserved and return no device.

OpenGL resources use RAII wrappers, but raw pointers passed into binding and command APIs are non-owning. Their owners must outlive command execution.

## Renderer

`RenderSystem` records and executes command buffers. The public render-pass set contains only implemented types:

- `ForwardRenderPass`;
- `ShadowMapPass`;
- `DeferredGeometryPass`;
- `DeferredLightingPass`.

The default pipeline uses shadow and forward rendering. The deferred setup uses shadow, geometry, and lighting passes.

Known constraints:

- compute `Dispatch` commands are logged but not executed;
- deferred setup still uses fixed initial dimensions and needs complete resize propagation;
- generic framebuffer binding and some attachment paths remain incomplete;
- render statistics do not yet represent complete GPU execution metrics.

## Scene and spatial management

`Scene` owns render objects, lights, environment settings, and a root hierarchy node. `SceneManager` owns named scenes, selects the active scene, manages an octree, and exposes point, sphere, box, ray, nearest-object, and visibility queries.

Public scene-manager methods now link consistently. Unsupported persistence operations return `false` and log an error instead of producing linker failures.

The octree supports insertion, removal, updates, rebuilding, configuration, nearest-neighbor queries, and public spatial helpers. Its current bounds are approximate and based on object position and scale, not imported mesh bounds.

Frustum-plane extraction and occlusion culling remain placeholder algorithms and must not be treated as production culling.

## Textures and framebuffers

The basic specification and file constructors create `OpenGLTexture2D` instances. Size-based, render-target, and solid-color convenience factories are defined for the basic color-texture path.

Depth formats are not mapped by `OpenGLTexture2D`; `CreateDepthTarget` therefore logs an error and returns `nullptr`. Depth attachments should be created through `OpenGLFramebuffer` until the texture-format mapping is completed.

## Image loading

`Image::Load` dispatches by extension:

- TGA: narrow uncompressed RGB/RGBA subset;
- BMP: narrow uncompressed 24/32-bit subset;
- PNG: custom non-interlaced path with DEFLATE/zlib handling;
- JPEG: marker parsing and helper stages, followed by a generated test pattern rather than real block reconstruction.

`ImageData::Data` is manually owned and must be released through `Image::Free`.

## Logging

The logger supports severity filtering, console/file output, rotation, structured fields, source locations, assertions, and thread synchronization. Engine subsystems use `PYRAMID_LOG_*` rather than direct console output.

## Build and package model

- `PyramidEngine` is the engine target; `Pyramid::Engine` is its build-tree alias and installed name.
- GLAD is a public dependency because OpenGL implementation headers expose GLAD types.
- Public headers are installed separately rather than exported through `INTERFACE_SOURCES`, keeping the package relocatable.
- CMake package configuration and version files support `find_package(PyramidEngine CONFIG REQUIRED)`.
- Windows CI validates an external consumer after installation.

## Dependency direction

```text
Application
    ↓
Core Game lifecycle
    ↓
Platform Window + Graphics Device
    ↓
Renderer / Scene / Camera / Resources
    ↓
Math + Utilities + GLAD + Win32/OpenGL
```

Avoid introducing platform handles into generic interfaces or renderer-specific ownership into scene data without an explicit lifetime model.
